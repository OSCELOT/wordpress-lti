Name: LTI_Tool_Provider.php
Author: Stephen P Vickers
Download: http://projects.oscelot.org/gf/projects/php-basic-lti/
Documentation: http://www.spvsoftwareproducts.com/php/lti_tool_provider/
